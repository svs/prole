({"quotes":
 [
	{
		"quote" : "I'm the greatest. I said that before I knew I was.",
		"author" : "Muhammed Ali"
	},
	
	{
		"quote" : "Code is Poetry.",
		"author" : "Wordpress.com"
	},
	{
		"quote" : "Life, Liberty, and the Pursuit of Javascript.",
		"author" : "? "
	}
	
]
 })